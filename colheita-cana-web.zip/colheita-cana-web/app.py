"""API + site do sistema de colheita de cana. Roda local (SQLite) e em Render/Railway (PostgreSQL)."""
import hmac, json, os, uuid
from flask import Flask, Response, abort, jsonify, request, send_from_directory
from sqlalchemy import create_engine, text

URL = os.environ.get("DATABASE_URL", "sqlite:///colheita_web.db")
if URL.startswith("postgres://"):
    URL = URL.replace("postgres://", "postgresql+psycopg2://", 1)
elif URL.startswith("postgresql://"):
    URL = URL.replace("postgresql://", "postgresql+psycopg2://", 1)
engine = create_engine(URL, pool_pre_ping=True)
with engine.begin() as c:
    c.execute(text("CREATE TABLE IF NOT EXISTS docs (col TEXT NOT NULL, id TEXT NOT NULL, "
                   "data TEXT NOT NULL, PRIMARY KEY (col, id))"))

COLS = {"fazendas", "frentes", "atr", "fretes", "colhedoras", "transbordos"}
SENHA = os.environ.get("APP_PASSWORD", "")
app = Flask(__name__, static_folder="static")


@app.before_request
def autenticar():
    if request.path == "/health" or not SENHA:
        return
    a = request.authorization
    if not (a and hmac.compare_digest(a.password or "", SENHA)):
        return Response("Acesso restrito", 401, {"WWW-Authenticate": 'Basic realm="Colheita"'})


def check(col):
    if col not in COLS:
        abort(404)


def gravar(c, col, id_, data):
    c.execute(text("INSERT INTO docs (col,id,data) VALUES (:c,:i,:d) "
                   "ON CONFLICT (col,id) DO UPDATE SET data = excluded.data"),
              {"c": col, "i": id_, "d": json.dumps(data, ensure_ascii=False)})


@app.get("/health")
def health():
    return "ok"


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/api/<col>")
def listar(col):
    check(col)
    with engine.connect() as c:
        rows = c.execute(text("SELECT id, data FROM docs WHERE col=:c ORDER BY id"), {"c": col}).all()
    return jsonify([{"id": r[0], **json.loads(r[1])} for r in rows])


@app.post("/api/<col>")
def criar(col):
    check(col)
    id_ = uuid.uuid4().hex[:12]
    with engine.begin() as c:
        gravar(c, col, id_, request.get_json(force=True) or {})
    return jsonify({"id": id_})


@app.put("/api/<col>/<id_>")
def substituir(col, id_):
    check(col)
    with engine.begin() as c:
        gravar(c, col, id_, request.get_json(force=True) or {})
    return jsonify({"id": id_})


@app.patch("/api/<col>/<id_>")
def atualizar(col, id_):
    check(col)
    with engine.begin() as c:
        r = c.execute(text("SELECT data FROM docs WHERE col=:c AND id=:i"), {"c": col, "i": id_}).first()
        if not r:
            abort(404)
        d = json.loads(r[0])
        d.update(request.get_json(force=True) or {})
        gravar(c, col, id_, d)
    return jsonify({"id": id_})


@app.delete("/api/<col>/<id_>")
def apagar(col, id_):
    check(col)
    with engine.begin() as c:
        c.execute(text("DELETE FROM docs WHERE col=:c AND id=:i"), {"c": col, "i": id_})
    return "", 204


if __name__ == "__main__":
    app.run(debug=True, port=int(os.environ.get("PORT", 5000)))
