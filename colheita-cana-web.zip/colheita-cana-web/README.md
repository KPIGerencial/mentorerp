# Colheita de cana: versão para hospedar (Render ou Railway)

Flask + PostgreSQL. A tela é a mesma do sistema web (`static/index.html`) e a API fica em `app.py`.

## Testar no seu computador
```
pip install -r requirements.txt
python app.py          # abre em http://localhost:5000 (usa SQLite local)
```
Depois, na aba "Fazendas e estimativa", importe a planilha AGR0190.xlsx.

## Hospedar no Render
1. Suba esta pasta para um repositório no GitHub.
2. No Render: New > Blueprint > escolha o repositório (ele lê o `render.yaml` e cria o site e o banco).
3. Quando pedir, defina `APP_PASSWORD` (a senha de acesso ao sistema).
4. Abra o endereço .onrender.com, digite qualquer usuário e a senha, e importe a planilha.

## Hospedar no Railway
1. Suba a pasta para o GitHub e crie New Project > Deploy from GitHub.
2. Adicione o serviço PostgreSQL ao projeto.
3. No serviço do site, em Variables: `DATABASE_URL` = referência à variável do Postgres, e `APP_PASSWORD` = sua senha.
4. Em Settings > Networking, gere o domínio público.

Sem `APP_PASSWORD` o sistema fica aberto para qualquer pessoa com o link. Sempre defina a senha.
